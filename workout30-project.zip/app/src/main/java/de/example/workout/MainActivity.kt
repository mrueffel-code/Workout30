package de.example.workout

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.CircularProgressIndicator
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Switch
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.ToggleChip
import kotlinx.coroutines.delay

private val GREEN = Color(0xFF4CAF50)
private val BLUE = Color(0xFF42A5F5)
private val RED = Color(0xFFEF5350)
private val GRAY = Color(0xFF9E9E9E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

private fun sendToService(ctx: Context, action: String) {
    val i = Intent(ctx, WorkoutService::class.java).setAction(action)
    if (action == WorkoutService.ACTION_START) ContextCompat.startForegroundService(ctx, i)
    else ctx.startService(i)
}

private fun fmt(sec: Int): String = "%02d:%02d".format(sec / 60, sec % 60)

@Composable
fun App() {
    val ui by WorkoutState.ui.collectAsState()
    when {
        ui.running -> WorkoutScreen(ui)
        ui.summary != null -> SummaryScreen(ui.summary!!)
        else -> HomeScreen(ui.error)
    }
}

// ------------------------------------------------------------------ Workout

@Composable
fun WorkoutScreen(ui: UiState) {
    val ctx = LocalContext.current
    val color = when (ui.status) {
        ZoneStatus.IN -> GREEN
        ZoneStatus.BELOW -> BLUE
        ZoneStatus.ABOVE -> RED
        ZoneStatus.UNKNOWN -> GRAY
    }
    val statusText = when (ui.status) {
        ZoneStatus.IN -> "In Zone"
        ZoneStatus.BELOW -> "Unter Zone"
        ZoneStatus.ABOVE -> "Über Zone"
        ZoneStatus.UNKNOWN -> "Suche Puls …"
    }
    val ringColor = if (ui.segType == SegmentType.WORK) Color(0xFFFF9800) else Color(0xFFCFD8DC)
    val progress = if (ui.totalSec > 0) ui.elapsedSec / ui.totalSec.toFloat() else 0f

    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(confirm) { if (confirm) { delay(3000); confirm = false } }

    Box(Modifier.fillMaxSize()) {
        CircularProgressIndicator(
            progress = progress,
            modifier = Modifier.fillMaxSize().padding(3.dp),
            strokeWidth = 6.dp,
            indicatorColor = ringColor,
            trackColor = Color(0x33FFFFFF),
        )
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(ui.label, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
            Text(fmt(ui.segRemainingSec), fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Text(
                "♥ " + (ui.hr?.toString() ?: "--"),
                fontSize = 28.sp, fontWeight = FontWeight.Bold, color = color,
            )
            Text("Ziel ${ui.lowBpm}–${ui.highBpm} bpm", fontSize = 12.sp)
            Text(statusText, fontSize = 12.sp, color = color, fontWeight = FontWeight.Medium)
            Text("${fmt(ui.elapsedSec)} / ${fmt(ui.totalSec)}", fontSize = 10.sp, color = GRAY)
            Spacer(Modifier.height(2.dp))
            Button(
                onClick = {
                    if (confirm) sendToService(ctx, WorkoutService.ACTION_STOP) else confirm = true
                },
                modifier = Modifier.size(30.dp),
            ) { Text(if (confirm) "✓" else "■", fontSize = 12.sp) }
        }
    }
}

// --------------------------------------------------------------------- Home

@Composable
fun HomeScreen(error: String?) {
    val ctx = LocalContext.current
    val settings = remember { Settings(ctx) }
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(enabled = showSettings) { showSettings = false }

    val permissions = buildList {
        add(Manifest.permission.BODY_SENSORS)
        add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.BODY_SENSORS] == true) {
            sendToService(ctx, WorkoutService.ACTION_START)
        }
    }

    if (showSettings) {
        SettingsScreen(settings) { showSettings = false }
        return
    }

    ScalingLazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item { Text("Intervall-Workout", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        item {
            val minutes = if (settings.longIntervals) 38 else 30
            Text("$minutes min · HFmax ${settings.hrMax()}", fontSize = 12.sp, color = GRAY)
        }
        if (error != null) {
            item { Text(error, fontSize = 11.sp, color = RED, textAlign = TextAlign.Center) }
        }
        item {
            Chip(
                modifier = Modifier.fillMaxWidth(),
                onClick = { launcher.launch(permissions) },
                label = { Text("Start") },
            )
        }
        item {
            Chip(
                modifier = Modifier.fillMaxWidth(),
                onClick = { showSettings = true },
                label = { Text("Einstellungen") },
            )
        }
    }
}

// ----------------------------------------------------------------- Settings

@Composable
fun SettingsScreen(s: Settings, onBack: () -> Unit) {
    var auto by remember { mutableStateOf(s.autoMax) }
    var age by remember { mutableStateOf(s.age) }
    var manual by remember { mutableStateOf(s.manualMax) }
    var voice by remember { mutableStateOf(s.voice) }
    var long by remember { mutableStateOf(s.longIntervals) }

    ScalingLazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item {
            ToggleChip(
                modifier = Modifier.fillMaxWidth(),
                checked = auto,
                onCheckedChange = { auto = it; s.autoMax = it },
                label = { Text("HFmax automatisch") },
                toggleControl = { Switch(checked = auto) },
            )
        }
        if (auto) {
            item { NumberRow("Alter", age, 12, 90) { age = it; s.age = it } }
            item {
                Text(
                    "HFmax ≈ ${s.hrMax()} bpm (208 − 0,7 × Alter)",
                    fontSize = 11.sp, color = GRAY, textAlign = TextAlign.Center,
                )
            }
        } else {
            item { NumberRow("HFmax (bpm)", manual, 120, 230) { manual = it; s.manualMax = it } }
        }
        item {
            ToggleChip(
                modifier = Modifier.fillMaxWidth(),
                checked = voice,
                onCheckedChange = { voice = it; s.voice = it },
                label = { Text("Sprachansagen") },
                toggleControl = { Switch(checked = voice) },
            )
        }
        item {
            ToggleChip(
                modifier = Modifier.fillMaxWidth(),
                checked = long,
                onCheckedChange = { long = it; s.longIntervals = it },
                label = { Text("4×(3+2 min), 38 min") },
                toggleControl = { Switch(checked = long) },
            )
        }
        item {
            Chip(
                modifier = Modifier.fillMaxWidth(),
                onClick = onBack,
                label = { Text("Zurück") },
            )
        }
    }
}

@Composable
fun NumberRow(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 12.sp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(
                onClick = { onChange((value - 1).coerceAtLeast(min)) },
                modifier = Modifier.size(ButtonDefaults.SmallButtonSize),
            ) { Text("–") }
            Text("$value", fontSize = 24.sp)
            Button(
                onClick = { onChange((value + 1).coerceAtMost(max)) },
                modifier = Modifier.size(ButtonDefaults.SmallButtonSize),
            ) { Text("+") }
        }
    }
}

// ------------------------------------------------------------------ Summary

@Composable
fun SummaryScreen(sum: Summary) {
    ScalingLazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item {
            Text(
                if (sum.completed) "Workout beendet" else "Abgebrochen",
                fontSize = 16.sp, fontWeight = FontWeight.Bold,
            )
        }
        item { Text("Dauer ${fmt(sum.durationSec)}") }
        item { Text("Ø Puls ${sum.avgHr} · Max ${sum.maxHr}") }
        item { Text("In Zone: ${sum.inZonePct} %", color = GREEN) }
        item {
            Text(
                if (sum.savedPath != null) "JSON gespeichert" else "Export fehlgeschlagen",
                fontSize = 11.sp, color = GRAY,
            )
        }
        item {
            Chip(
                modifier = Modifier.fillMaxWidth(),
                onClick = { WorkoutState.reset() },
                label = { Text("OK") },
            )
        }
    }
}
