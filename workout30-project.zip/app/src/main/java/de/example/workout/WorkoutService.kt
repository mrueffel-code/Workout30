package de.example.workout

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.health.services.client.ExerciseClient
import androidx.health.services.client.ExerciseUpdateCallback
import androidx.health.services.client.HealthServices
import androidx.health.services.client.data.Availability
import androidx.health.services.client.data.DataType
import androidx.health.services.client.data.ExerciseConfig
import androidx.health.services.client.data.ExerciseLapSummary
import androidx.health.services.client.data.ExerciseType
import androidx.health.services.client.data.ExerciseUpdate
import com.google.common.util.concurrent.FutureCallback
import com.google.common.util.concurrent.Futures
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WorkoutService : Service() {

    companion object {
        const val ACTION_START = "de.example.workout.START"
        const val ACTION_STOP = "de.example.workout.STOP"
        private const val CHANNEL_ID = "workout"
        private const val NOTIF_ID = 1
        private const val TAG = "WorkoutService"

        private const val OVER_MARGIN_BPM = 10   // Alarm ab Zone-Obergrenze + 10 bpm
        private const val GRACE_SEC = 30         // Schonfrist nach Segmentwechsel
        private const val OVER_REPEAT_SEC = 30   // Mindestabstand zwischen Warn-Vibrationen
        private const val HR_STALE_MS = 5_000L   // Puls älter als 5 s gilt als "kein Signal"

        private val VIB_PHASE = longArrayOf(0, 400, 150, 400)
        private val VIB_OVER = longArrayOf(0, 150, 100, 150, 100, 150)
        private val VIB_FINISH = longArrayOf(0, 600, 200, 600, 200, 600)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var exerciseClient: ExerciseClient

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var plan: WorkoutPlan? = null
    private var hrMax = 190
    private var voice = true
    private var active = false

    private var startReal = 0L
    private var startWall = 0L
    private var lastHr: Int? = null
    private var lastHrAt = 0L
    private var lastIdx = -1
    private var lastOverAlert = -1_000
    private var tickJob: Job? = null
    private val samples = mutableListOf<Sample>()

    private val callback = object : ExerciseUpdateCallback {
        override fun onRegistered() {}
        override fun onRegistrationFailed(throwable: Throwable) {
            Log.e(TAG, "Registrierung fehlgeschlagen", throwable)
        }
        override fun onAvailabilityChanged(dataType: DataType<*, *>, availability: Availability) {}
        override fun onLapSummaryReceived(lapSummary: ExerciseLapSummary) {}
        override fun onExerciseUpdateReceived(update: ExerciseUpdate) {
            val bpm = update.latestMetrics.getData(DataType.HEART_RATE_BPM)
                .lastOrNull()?.value?.toInt() ?: return
            lastHr = bpm
            lastHrAt = SystemClock.elapsedRealtime()
        }
    }

    override fun onCreate() {
        super.onCreate()
        exerciseClient = HealthServices.getClient(this).exerciseClient
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.GERMAN)
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (!active) begin() else Unit
            ACTION_STOP -> finish(completed = false)
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- Start

    private fun begin() {
        val settings = Settings(this)
        hrMax = settings.hrMax()
        voice = settings.voice
        val p = WorkoutPlan.create(settings.longIntervals)
        plan = p

        samples.clear()
        lastHr = null
        lastIdx = -1
        lastOverAlert = -1_000
        active = true

        goForeground()
        acquireWakeLock(p.totalSec)

        val config = ExerciseConfig.builder(ExerciseType.RUNNING)
            .setDataTypes(setOf(DataType.HEART_RATE_BPM))
            .setIsAutoPauseAndResumeEnabled(false)
            .setIsGpsEnabled(false)
            .build()

        exerciseClient.setUpdateCallback(callback)
        val future = exerciseClient.startExerciseAsync(config)
        Futures.addCallback(future, object : FutureCallback<Void?> {
            override fun onSuccess(result: Void?) {}
            override fun onFailure(t: Throwable) {
                Log.e(TAG, "startExercise fehlgeschlagen", t)
                abort("Start fehlgeschlagen. Läuft ein anderes Workout (z. B. Samsung Health)?")
            }
        }, ContextCompat.getMainExecutor(this))

        startReal = SystemClock.elapsedRealtime()
        startWall = System.currentTimeMillis()
        WorkoutState.ui.value = UiState(running = true, totalSec = p.totalSec)

        tickJob = scope.launch {
            while (isActive) {
                val elapsedMs = SystemClock.elapsedRealtime() - startReal
                val elapsed = (elapsedMs / 1000).toInt()
                if (elapsed >= p.totalSec) {
                    finish(completed = true)
                    break
                }
                tick(p, elapsed)
                delay(1000 - elapsedMs % 1000)   // sekundengenau ausrichten
            }
        }
    }

    // ----------------------------------------------------------------- Tick

    private fun tick(p: WorkoutPlan, elapsed: Int) {
        val idx = p.indexAt(elapsed)
        if (idx < 0) return
        val seg = p.segments[idx]

        if (idx != lastIdx) {
            lastIdx = idx
            vibrate(VIB_PHASE)
            speak(seg.announcement())
        }

        val now = SystemClock.elapsedRealtime()
        val hr = lastHr?.takeIf { now - lastHrAt <= HR_STALE_MS }
        val (low, high) = seg.bpmRange(hrMax)
        val status = zoneStatus(hr, low, high)

        if (hr != null &&
            hr >= high + OVER_MARGIN_BPM &&
            elapsed - seg.startSec >= GRACE_SEC &&
            elapsed - lastOverAlert >= OVER_REPEAT_SEC
        ) {
            lastOverAlert = elapsed
            vibrate(VIB_OVER)
        }

        samples += Sample(elapsed, hr, idx, status)

        WorkoutState.ui.value = UiState(
            running = true,
            label = seg.label(),
            segType = seg.type,
            segRemainingSec = seg.endSec - elapsed,
            elapsedSec = elapsed,
            totalSec = p.totalSec,
            hr = hr,
            lowBpm = low,
            highBpm = high,
            status = status,
        )
    }

    // ----------------------------------------------------------------- Ende

    private fun finish(completed: Boolean) {
        if (!active) { stopSelf(); return }
        active = false
        tickJob?.cancel()
        shutdownSensors()

        val saved = runCatching { export(completed) }.getOrNull()
        WorkoutState.ui.value = UiState(summary = buildSummary(completed, saved))

        vibrate(VIB_FINISH)
        if (completed) speak("Workout beendet. Gut gemacht.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        scope.launch { delay(6_000); stopSelf() }   // Zeit für die letzte Ansage
    }

    private fun abort(message: String) {
        if (!active) return
        active = false
        tickJob?.cancel()
        shutdownSensors()
        WorkoutState.ui.value = UiState(error = message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun shutdownSensors() {
        runCatching { exerciseClient.endExerciseAsync() }
        runCatching { exerciseClient.clearUpdateCallbackAsync(callback) }
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun buildSummary(completed: Boolean, path: String?): Summary {
        val valid = samples.filter { it.hr != null }
        val hrs = valid.map { it.hr!! }
        return Summary(
            completed = completed,
            durationSec = samples.lastOrNull()?.t ?: 0,
            avgHr = if (hrs.isEmpty()) 0 else hrs.average().toInt(),
            maxHr = hrs.maxOrNull() ?: 0,
            inZonePct = if (valid.isEmpty()) 0
            else valid.count { it.status == ZoneStatus.IN } * 100 / valid.size,
            savedPath = path,
        )
    }

    // ---------------------------------------------------------- JSON-Export

    private fun export(completed: Boolean): String {
        val p = plan ?: error("kein Plan")
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US)
        val root = JSONObject()
            .put("startedAt", iso.format(Date(startWall)))
            .put("hrMax", hrMax)
            .put("completed", completed)
            .put("durationSec", samples.lastOrNull()?.t ?: 0)

        val planJson = JSONArray()
        p.segments.forEach { s ->
            val (lo, hi) = s.bpmRange(hrMax)
            planJson.put(
                JSONObject().put("type", s.type.name).put("startSec", s.startSec)
                    .put("durationSec", s.durationSec).put("lowBpm", lo).put("highBpm", hi)
                    .put("round", s.round)
            )
        }
        root.put("plan", planJson)

        val sampleJson = JSONArray()
        samples.forEach { s ->
            sampleJson.put(
                JSONObject().put("t", s.t).put("hr", s.hr ?: JSONObject.NULL)
                    .put("segment", s.seg).put("status", s.status.name)
            )
        }
        root.put("samples", sampleJson)

        val dir = File(filesDir, "workouts").apply { mkdirs() }
        val name = "workout_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(startWall)) + ".json"
        val file = File(dir, name)
        file.writeText(root.toString(2))
        return file.absolutePath
    }

    // ------------------------------------------------------------- Helfer

    private fun speak(text: String) {
        if (voice && ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ann")
    }

    @Suppress("DEPRECATION")
    private fun vibrate(pattern: LongArray) {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31)
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        else getSystemService(Vibrator::class.java)
        v?.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }

    private fun acquireWakeLock(totalSec: Int) {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "workout:service").apply {
            acquire((totalSec + 300) * 1000L)
        }
    }

    private fun goForeground() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Workout", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Workout läuft")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
