package de.example.workout

import android.content.Context
import kotlin.math.roundToInt

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var autoMax: Boolean
        get() = p.getBoolean("auto", true)
        set(v) { p.edit().putBoolean("auto", v).apply() }

    var age: Int
        get() = p.getInt("age", 35)
        set(v) { p.edit().putInt("age", v).apply() }

    var manualMax: Int
        get() = p.getInt("manual", 185)
        set(v) { p.edit().putInt("manual", v).apply() }

    var voice: Boolean
        get() = p.getBoolean("voice", true)
        set(v) { p.edit().putBoolean("voice", v).apply() }

    var longIntervals: Boolean
        get() = p.getBoolean("long", false)
        set(v) { p.edit().putBoolean("long", v).apply() }

    /** Automatisch: Tanaka-Formel 208 - 0,7 x Alter. */
    fun hrMax(): Int = if (autoMax) (208 - 0.7 * age).roundToInt() else manualMax
}
