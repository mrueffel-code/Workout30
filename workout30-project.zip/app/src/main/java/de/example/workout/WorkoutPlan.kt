package de.example.workout

import kotlin.math.roundToInt

enum class SegmentType { WARMUP, BUILDUP, WORK, RECOVERY, COOLDOWN }

data class Segment(
    val type: SegmentType,
    val startSec: Int,
    val durationSec: Int,
    val lowPct: Double,
    val highPct: Double,
    val round: Int = 0,
    val rounds: Int = 0,
) {
    val endSec get() = startSec + durationSec

    fun bpmRange(hrMax: Int): Pair<Int, Int> =
        (hrMax * lowPct).roundToInt() to (hrMax * highPct).roundToInt()

    fun label(): String = when (type) {
        SegmentType.WARMUP -> "Aufwärmen"
        SegmentType.BUILDUP -> "Build-up"
        SegmentType.WORK -> "Intervall $round/$rounds – Belastung"
        SegmentType.RECOVERY -> "Intervall $round/$rounds – Erholung"
        SegmentType.COOLDOWN -> "Cool-down"
    }

    fun announcement(): String = when (type) {
        SegmentType.WARMUP -> "Aufwärmen beginnt"
        SegmentType.BUILDUP -> "Build-up beginnt"
        SegmentType.WORK -> "Intervall $round beginnt. Belastung."
        SegmentType.RECOVERY -> "Erholung"
        SegmentType.COOLDOWN -> "Cool-down beginnt"
    }
}

/** Fester Trainingsplan. Alle Zeiten in Sekunden. */
class WorkoutPlan(val segments: List<Segment>) {
    val totalSec: Int = segments.last().endSec

    /** Index des aktiven Segments oder -1, wenn das Workout vorbei ist. */
    fun indexAt(elapsedSec: Int): Int = segments.indexOfFirst { elapsedSec < it.endSec }

    companion object {
        /**
         * longIntervals = false: 4 x (1:48 Belastung + 1:12 Erholung) = 12:00
         *   -> Gesamt exakt 30:00 (Phasen wie spezifiziert: 5/5/12/8 Minuten)
         * longIntervals = true : 4 x (3:00 Belastung + 2:00 Erholung) = 20:00
         *   -> Gesamt 38:00
         */
        fun create(longIntervals: Boolean): WorkoutPlan {
            val list = mutableListOf<Segment>()
            var t = 0
            fun add(type: SegmentType, dur: Int, lo: Double, hi: Double, round: Int = 0) {
                list += Segment(type, t, dur, lo, hi, round, if (round > 0) 4 else 0)
                t += dur
            }
            val work = if (longIntervals) 180 else 108
            val rec = if (longIntervals) 120 else 72

            add(SegmentType.WARMUP, 300, 0.50, 0.60)
            add(SegmentType.BUILDUP, 300, 0.60, 0.70)
            for (i in 1..4) {
                add(SegmentType.WORK, work, 0.85, 0.90, i)      // Zone 4
                add(SegmentType.RECOVERY, rec, 0.50, 0.70, i)   // Zone 1-2
            }
            add(SegmentType.COOLDOWN, 480, 0.50, 0.60)
            return WorkoutPlan(list)
        }
    }
}

fun zoneStatus(hr: Int?, low: Int, high: Int): ZoneStatus = when {
    hr == null -> ZoneStatus.UNKNOWN
    hr < low -> ZoneStatus.BELOW
    hr > high -> ZoneStatus.ABOVE
    else -> ZoneStatus.IN
}
