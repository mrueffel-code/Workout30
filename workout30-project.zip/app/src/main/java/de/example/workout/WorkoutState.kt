package de.example.workout

import kotlinx.coroutines.flow.MutableStateFlow

enum class ZoneStatus { UNKNOWN, BELOW, IN, ABOVE }

data class Sample(val t: Int, val hr: Int?, val seg: Int, val status: ZoneStatus)

data class Summary(
    val completed: Boolean,
    val durationSec: Int,
    val avgHr: Int,
    val maxHr: Int,
    val inZonePct: Int,
    val savedPath: String?,
)

data class UiState(
    val running: Boolean = false,
    val label: String = "",
    val segType: SegmentType? = null,
    val segRemainingSec: Int = 0,
    val elapsedSec: Int = 0,
    val totalSec: Int = 0,
    val hr: Int? = null,
    val lowBpm: Int = 0,
    val highBpm: Int = 0,
    val status: ZoneStatus = ZoneStatus.UNKNOWN,
    val summary: Summary? = null,
    val error: String? = null,
)

/** Brücke zwischen Service und UI. */
object WorkoutState {
    val ui = MutableStateFlow(UiState())
    fun reset() { ui.value = UiState() }
}
